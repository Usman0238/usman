import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "/Print" ,urlPatterns ={"/Print"} )
public class Print extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {




            // do some processing here...

            // get response writer
            PrintWriter writer = response.getWriter();

            // build HTML code
            String htmlRespone = "<!DOCTYPE html>\n" +
                    "<html lang=\"en\" dir=\"ltr\">\n" +
                    "  <head>\n" +
                    "    <meta charset=\"utf-8\">\n" +
                    "    <title>UMT Admission Form</title>\n" +
                    "    <link rel=\"preconnect\" href=\"https://fonts.gstatic.com\">\n" +
                    "    <link href=\"https://fonts.googleapis.com/css2?family=Open+Sans&family=Roboto&display=swap\" rel=\"stylesheet\">\n" +
                    "    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6\" crossorigin=\"anonymous\">\n" +
                    "    <link rel=\"icon\" href=\"UMT_Logo.png\">\n" +
                    "    <link rel=\"stylesheet\" href=\"style.css\">\n" +
                    "  </head>\n" +
                    "  <body>\n" +
                    "    <div class=\"background\">\n" +
                    "        <div class=\"maindiv\">\n" +
                    "          <div class=\"continer\">\n" +
                    "\n" +
                    "\n" +
                    "              <div class=\"row\">\n" +
                    "                <div class=\"col\">\n" +
                    "                  <div class=\"row\">\n" +
                    "                    <label for=\"fName\" class=\"col-md-4 col-form-label textalin\">First Name:</label>\n" +
                    "                    <div class=\"col-md-8\">\n" +
                    "                      <input type=\"text\" class=\"form-control\" placeholder=\"Name\">\n" +
                    "                    </div>\n" +
                    "                  </div>\n" +
                    "                </div>\n" +
                    "                <div class=\"col\">\n" +
                    "                  <div class=\"row\">\n" +
                    "                    <label for=\"fName\" class=\"col-md-4 col-form-label textalin\">Last Name:</label>\n" +
                    "                    <div class=\"col-md-8\">\n" +
                    "                      <input type=\"text\" class=\"form-control\" placeholder=\"Last Name\">\n" +
                    "                    </div>\n" +
                    "                  </div>\n" +
                    "                </div>\n" +
                    "              </div>\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "              <div class=\"row\">\n" +
                    "                <div class=\"col\">\n" +
                    "                  <div class=\"row\">\n" +
                    "                    <label for=\"email\" class=\"col-md-4 col-form-label textalin\">Eamil:</label>\n" +
                    "                    <div class=\"col-md-8\">\n" +
                    "                      <input type=\"email\" class=\"form-control\" placeholder=\"Eamil\">\n" +
                    "                    </div>\n" +
                    "                  </div>\n" +
                    "                </div>\n" +
                    "                <div class=\"col\">\n" +
                    "                  <div class=\"row\">\n" +
                    "                    <label for=\"fName\" class=\"col-md-4 col-form-label textalin\">Phone Number:</label>\n" +
                    "                    <div class=\"col-md-8\">\n" +
                    "                      <input type=\"Phone\" class=\"form-control\" placeholder=\"Phone Number\">\n" +
                    "                    </div>\n" +
                    "                  </div>\n" +
                    "                </div>\n" +
                    "              </div>\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "              <div class=\"row\">\n" +
                    "                <div class=\"col\">\n" +
                    "                  <div class=\"row\">\n" +
                    "                        <label for=\"dateOfBirth\" class=\"col-md-4 col-form-label textalin\">Date Of Birth: </label>\n" +
                    "                        <div class=\"col-md-8\">\n" +
                    "                          <input type=\"date\" class=\"form-control textalin\" style=\"color:#00b0fc80; opacity:60%\">\n" +
                    "                        </div>\n" +
                    "                  </div>\n" +
                    "                </div>\n" +
                    "                <div class=\"col\">\n" +
                    "                  <div class=\"row\">\n" +
                    "                    <label for=\"gender\" class=\"col-md-4 col-form-label textalin\">Gender: </label>\n" +
                    "                    <div class=\"col-md-6 textalin\" style=\"padding-top:10px\">\n" +
                    "                      <div class=\"form-check form-check-inline textalin\">\n" +
                    "                        <input class=\"form-check-input\" type=\"radio\"name=\"inlineRadioOptions\" style=\"width: 0.8em; height: 0.8em\">\n" +
                    "                        <label class=\"form-check-label\" for=\"Male\">Male</label>\n" +
                    "                      </div>\n" +
                    "                      <div class=\"form-check form-check-inline\">\n" +
                    "                        <input class=\"form-check-input\" type=\"radio\" name=\"inlineRadioOptions\" style=\"width: 0.8em; height: 0.8em\">\n" +
                    "                        <label class=\"form-check-label\" for=\"Female\">Female</label>\n" +
                    "                      </div>\n" +
                    "                    </div>\n" +
                    "                  </div>\n" +
                    "                </div>\n" +
                    "              </div>\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "              <div class=\"row\">\n" +
                    "                <label for=\"address\" class=\"col-md-2 col-form-label textalin\">Full Address: </label>\n" +
                    "                <div class=\"col-md-10\">\n" +
                    "                  <input type=\"text\" class=\"form-control textalin\" placeholder=\"Address\">\n" +
                    "                </div>\n" +
                    "              </div>\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "              <div class=\"row\">\n" +
                    "                <div class=\"col-md-4\">\n" +
                    "                  <div class=\"row\">\n" +
                    "                    <label for=\"city\" class=\"col-md-3 col-form-label textalin\">City:</label>\n" +
                    "                    <div class=\"col-md-9\">\n" +
                    "                      <input type=\"text\" class=\"form-control textalin\">\n" +
                    "                    </div>\n" +
                    "                  </div>\n" +
                    "                </div>\n" +
                    "                <div class=\"col-md-5\">\n" +
                    "                  <div class=\"row\">\n" +
                    "                    <label for=\"State\" class=\"col-md-6 col-form-label textalin\">State/Province:</label>\n" +
                    "                    <div class=\"col-md-6\">\n" +
                    "                      <input type=\"text\" class=\"form-control textalin\">\n" +
                    "                    </div>\n" +
                    "                  </div>\n" +
                    "                </div>\n" +
                    "                <div class=\"col-md-3\">\n" +
                    "                  <div class=\"row\">\n" +
                    "                    <label for=\"zip\" class=\"col-md-5 col-form-label textalin\">Zip Code:</label>\n" +
                    "                    <div class=\"col-md-7\">\n" +
                    "                      <input type=\"text\" class=\"form-control textalin\">\n" +
                    "                    </div>\n" +
                    "                </div>\n" +
                    "\n" +
                    "                </div>\n" +
                    "              </div>\n" +
                    "\n" +
                    "\n" +
                    "                <div class=\"row\">\n" +
                    "                  <div class=\"col-md-3\">\n" +
                    "                    <div class=\"row\">\n" +
                    "                      <label for=\"country\" class=\"col-md-6 col-form-label textalin\">Country:</label>\n" +
                    "                      <div class=\"col-md-6\">\n" +
                    "                        <input type=\"text\" class=\"form-control textalin\">\n" +
                    "                      </div>\n" +
                    "                    </div>\n" +
                    "                  </div>\n" +
                    "                  <div class=\"col-md-6\">\n" +
                    "                    <div class=\"row\">\n" +
                    "                      <label for=\"hobbies\" class=\"col-md-3 col-form-label textalin\">Hobbies:</label>\n" +
                    "                      <div class=\"col-md-9 textalin\" style=\"padding-top:10px\">\n" +
                    "                        <div class=\"form-check form-check-inline textalin\">\n" +
                    "                          <label class=\"form-check-label\" for=\"drawing\">Drawing</label>\n" +
                    "                          <input class=\"form-check-input\" type=\"radio\" style=\"width: 0.8em; height: 0.8em\">\n" +
                    "                        </div>\n" +
                    "                        <div class=\"form-check form-check-inline\">\n" +
                    "                          <input class=\"form-check-input\" type=\"radio\" style=\"width: 0.8em; height: 0.8em\">\n" +
                    "                          <label class=\"form-check-label\" for=\"singing\">Singing</label>\n" +
                    "                        </div>\n" +
                    "                        <div class=\"form-check form-check-inline\">\n" +
                    "                          <input class=\"form-check-input\" type=\"radio\" style=\"width: 0.8em; height: 0.8em\">\n" +
                    "                          <label class=\"form-check-label\" for=\"dancing\">Dancing</label>\n" +
                    "                        </div>\n" +
                    "                        <div class=\"form-check form-check-inline\">\n" +
                    "                          <input class=\"form-check-input\" type=\"radio\" style=\"width: 0.8em; height: 0.8em\">\n" +
                    "                          <label class=\"form-check-label\" for=\"sketching\">Sketching</label>\n" +
                    "                        </div>\n" +
                    "                      </div>\n" +
                    "                    </div>\n" +
                    "                 </div>\n" +
                    "                    <div class=\"col-md-3\">\n" +
                    "                      <div class=\"row\">\n" +
                    "                        <label for=\"other\" class=\"col-md-5 col-form-label textalin\">Others:</label>\n" +
                    "                        <div class=\"col-md-7\">\n" +
                    "                          <input type=\"text\" class=\"form-control\" >\n" +
                    "                        </div>\n" +
                    "                    </div>\n" +
                    "                    </div>\n" +
                    "                </div>\n" +
                    "\n" +
                    "                <div class=\"row\">\n" +
                    "                  <label for=\"qualification\" class=\"col-lg-2 col-md-3 col-form-label textalin \">Qualification</label>\n" +
                    "                  <div class=\"col-lg-8 col-md-9\">\n" +
                    "                    <table>\n" +
                    "                      <tr>\n" +
                    "                        <th>SI.No.Examination</th>\n" +
                    "                        <th>Board</th>\n" +
                    "                        <th>Percentage</th>\n" +
                    "                        <th>Year of Passing</th>\n" +
                    "                      </tr>\n" +
                    "                      <tr>\n" +
                    "                        <th>Class X</th>\n" +
                    "                        <td><input type=\"text\" class=\"form-control\"></td>\n" +
                    "                        <td><input type=\"text\" class=\"form-control\"></td>\n" +
                    "                        <td><input type=\"text\" class=\"form-control\"></td>\n" +
                    "                      </tr>\n" +
                    "                      <tr>\n" +
                    "                        <th>Class XII</th>\n" +
                    "                        <td><input type=\"text\" class=\"form-control\"></td>\n" +
                    "                        <td><input type=\"text\" class=\"form-control\"></td>\n" +
                    "                        <td><input type=\"text\" class=\"form-control\"></td>\n" +
                    "                      </tr>\n" +
                    "                      <tr>\n" +
                    "                        <th>Graduation</th>\n" +
                    "                        <td><input type=\"text\" class=\"form-control\"></td>\n" +
                    "                        <td><input type=\"text\" class=\"form-control\"></td>\n" +
                    "                        <td><input type=\"text\" class=\"form-control\"></td>\n" +
                    "                      </tr>\n" +
                    "                      <tr>\n" +
                    "                        <th>Masters</th>\n" +
                    "                        <td><input type=\"text\" class=\"form-control\"></td>\n" +
                    "                        <td><input type=\"text\" class=\"form-control\"></td>\n" +
                    "                        <td><input type=\"text\" class=\"form-control\"></td>\n" +
                    "                      </tr>\n" +
                    "                    </table>\n" +
                    "                  </div>\n" +
                    "                  <div class=\"col-lg-2\">\n" +
                    "                    <div class=\"row\">\n" +
                    "                      <label for=\"course\" class=\"col-form-label textalin\">Courses Applied For:</label>\n" +
                    "                      <div class=\"textalin\" style=\"padding-top:10px\">\n" +
                    "                        <div class=\"form-check form-check-inline textalin\">\n" +
                    "                          <label class=\"form-check-label\" for=\"bca\">BCA</label>\n" +
                    "                          <input class=\"form-check-input\" type=\"radio\" style=\"width: 0.8em; height: 0.8em\">\n" +
                    "                        </div>\n" +
                    "                        <div class=\"form-check form-check-inline\">\n" +
                    "                          <input class=\"form-check-input\" type=\"radio\" style=\"width: 0.8em; height: 0.8em\">\n" +
                    "                          <label class=\"form-check-label\" for=\"B.Com\">B.Com</label>\n" +
                    "                        </div>\n" +
                    "                        <div class=\"form-check form-check-inline\">\n" +
                    "                          <input class=\"form-check-input\" type=\"radio\" style=\"width: 0.8em; height: 0.8em\">\n" +
                    "                          <label class=\"form-check-label\" for=\"b.sc\">B.Sc</label>\n" +
                    "                        </div>\n" +
                    "                        <div class=\"form-check form-check-inline\">\n" +
                    "                          <input class=\"form-check-input\" type=\"radio\" style=\"width: 0.8em; height: 0.8em\">\n" +
                    "                          <label class=\"form-check-label\" for=\"b.a\">B.A</label>\n" +
                    "                        </div>\n" +
                    "                      </div>\n" +
                    "                    </div>\n" +
                    "                  </div>\n" +
                    "                </div>\n" +
                    "\n" +
                    "                <div class=\"row\">\n" +
                    "                  <div class=\"col\" style=\"margin-top:.5em\">\n" +
                    "                    <button type=\"button\" class=\"btn btn-primary\" name=\"button\">Submit</button>\n" +
                    "                    <button type=\"button\" class=\"btn btn-primary\" name=\"reset\">Reset</button>\n" +
                    "                  </div>\n" +
                    "                </div>\n" +
                    "\n" +
                    "\n" +
                    "              </div>\n" +
                    "\n" +
                    "\n" +
                    "          </div>\n" +
                    "        </div>\n" +
                    "\n" +
                    "\n" +
                    "  </body>\n" +
                    "</html>\n";
            // return response
            writer.println(htmlRespone);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
